# Core utilities and configurations
